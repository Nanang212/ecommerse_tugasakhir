<div class="product-section section section-padding">
    <div class="container">

        <div class="row">
            <div class="section-title text-center col mb-30">
                <h1>Popular Products</h1>
                <p>All popular product find here</p>
            </div>
        </div>

        <div class="row mbn-40">
          @foreach ($product as $result)
          <?php
            $kategori = $result->kategoriproduk_id;
            $product = DB::table('kategoriproduk')->where('id', $kategori)->first();
            $namaKategori = $product->nama;
            $slug = $product->slug;
          ?>
            <div class="col-xl-3 col-lg-4 col-md-6 col-12 mb-40">

                <div class="product-item">
                    <div class="product-inner">

                        <div class="image">
                            <img src="{{asset('assets/product/'.$result->gambar1)}}" alt="">

                            <div class="image-overlay">
                                <div class="action-buttons">
                                    {{-- <button>add to cart</button> --}}
                                    <?php
                                      $email = Session::get('email');
                                      if($email){
                                    ?>
                                    <li><a href="javascript:;" id="keranjang1{{ $result->id }}" title="Add to cart">Add to cart</a></li>
                                    <?php
                                      }else{
                                        $segmen = Request::segment(1);
                                        if($segmen){
                                        ?>
                                        <li><a href="/loginsegmen/{{ Request::segment(1) }}" title="Add to cart">Add to cart</a></li>
                                        <?php }else{ ?>
                                          <li><a href="/login" title="Add to cart">Add to cart</a></li>
                                        <?php } ?>
                                    <?php } ?>
                                </div>
                            </div>

                        </div>

                        <div class="content">

                            <div class="content-left">

                                <h4 class="title"><a href="{{ $result->slug }}">{{ $result->nama }}</a></h4>

                                {{-- <div class="ratting">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </div>

                                <h5 class="size">Size: <span>S</span><span>M</span><span>L</span><span>XL</span></h5>
                                <h5 class="color">Color: <span style="background-color: #ffb2b0"></span><span style="background-color: #0271bc"></span><span style="background-color: #efc87c"></span><span style="background-color: #00c183"></span></h5> --}}

                            </div>

                            <div class="content-right">
                                <span class="price">Rp {{ number_format($result->harga) }}</span>
                            </div>

                        </div>

                    </div>
                </div>

            </div>
          @endforeach
        </div>

    </div>
</div><!-- Product Section End -->
