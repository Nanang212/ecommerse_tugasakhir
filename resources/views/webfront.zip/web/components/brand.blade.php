<div class="brand-section section section-padding pt-50">
    <div class="container-fluid">
        <div class="row">
            <div class="brand-slider">

                <div class="brand-item col">
                    <img src="{{asset('web/images/brands/brand-1.png')}}" alt="">
                </div>

                <div class="brand-item col">
                    <img src="{{asset('web/images/brands/brand-2.png')}}" alt="">
                </div>

                <div class="brand-item col">
                    <img src="{{asset('web/images/brands/brand-3.png')}}" alt="">
                </div>

                <div class="brand-item col">
                    <img src="{{asset('web/images/brands/brand-4.png')}}" alt="">
                </div>

                <div class="brand-item col">
                    <img src="{{asset('web/images/brands/brand-5.png')}}" alt="">
                </div>

                <div class="brand-item col">
                    <img src="{{asset('web/images/brands/brand-6.png')}}" alt="">
                </div>

            </div>
        </div>
    </div>
</div><!-- Brand Section End -->
