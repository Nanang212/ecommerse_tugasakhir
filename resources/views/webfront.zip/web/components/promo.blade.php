<div class="banner-section section section-padding pt-0 fix">
    <div class="row row-5 mbn-10">

        <div class="col-lg-4 col-md-6 col-12 mb-10">
            <div class="banner banner-3">

                <a href="#" class="image"><img src="{{asset('web/images/banner/banner-4.jpg')}}" alt="Banner Image"></a>

                <div class="content" style="background-image: url(./web/images/banner/banner-3-shape.png)">
                    <h1>New Arrivals</h1>
                    <h2>Up to 35% off</h2>
                    <h4>2 - 5 Years</h4>
                </div>

                <a href="#" class="shop-link" data-hover="SHOP NOW">SHOP NOW</a>

            </div>
        </div>

        <div class="col-lg-4 col-md-6 col-12 mb-10">
            <div class="banner banner-4">

                <a href="#" class="image"><img src="{{asset('web/images/banner/banner-5.jpg')}}" alt="Banner Image"></a>

                <div class="content">
                    <div class="content-inner">
                        <h1>Online Shopping</h1>
                        <h2>Flat 25% off <br>New Trend for 2018</h2>
                        <a href="#" data-hover="SHOP NOW">SHOP NOW</a>
                    </div>
                </div>


            </div>
        </div>

        <div class="col-lg-4 col-md-6 col-12 mb-10">
            <div class="banner banner-5">

                <a href="#" class="image"><img src="{{asset('web/images/banner/banner-6.jpg')}}" alt="Banner Image"></a>

                <div class="content" style="background-image: url(./web/images/banner/banner-5-shape.png)">
                    <h1>Collection for <br>Baby Girl’s</h1>
                    <h2>Flat 25% off</h2>
                </div>

                <a href="#" class="shop-link" data-hover="SHOP NOW">SHOP NOW</a>

            </div>
        </div>

    </div>
</div><!-- Banner Section End -->
