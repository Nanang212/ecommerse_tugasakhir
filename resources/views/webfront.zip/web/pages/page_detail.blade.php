@extends('layouts.web')

@section('title')
  {{ $page->meta_title ? $page->meta_title : 'Store 1' }}
@endsection

@section('description')
  {{ $page->meta_deskripsi ? $page->meta_deskripsi : 'Store 1' }}
@endsection

@section('keyword')
  {{ $page->meta_keyword ? $page->meta_keyword : 'Store 1' }}
@endsection

@section('content')
  <!-- konten -->
  <!-- Preloader Start -->
  <div class="zakas-preloader active">
    <div class="zakas-preloader-inner h-100 d-flex align-items-center justify-content-center">
      <div class="zakas-child zakas-bounce1"></div>
      <div class="zakas-child zakas-bounce2"></div>
      <div class="zakas-child zuka-bounce3"></div>
    </div>
  </div>
  <!-- Preloader End -->

  <!-- Main Wrapper Start -->
  <div class="wrapper">
    <!-- Header Start -->
    @include('web.components.header')
    <!-- Header End -->

    <!-- Breadcrumb area Start -->
    <div class="breadcrumb-area bg-color ptb--90" data-bg-color="#f6f6f6">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                        <h1 class="page-title">{{ $page->nama }}</h1>
                        <ul class="breadcrumb">
                            <li><a href="{{route('home')}}">Home</a></li>
                            <li class="current"><span>{{ $page->nama }}</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb area End -->

    <!-- Main Content Wrapper Start -->
    <div class="main-content-wrapper">
      <div class="page-content-inner ptb--80">
        <div class="container">
          <div class="row mb--75">
            <div class="col-lg-12 col-xl-12 mb-md--50">
              <div class="single-post">
                <!-- Single Blog Start Here -->
                <article class="single-post-details">
                  <div class="entry-header">
                    <h2 class="entry-title">{{ $page->nama }}</h2>
                  </div>
                  <?php
                    $gambar = $page->gambar;
                    if($gambar){
                  ?>
                  <div class="entry-media">
                    <div class="image">
                      <img src="{{asset('assets/aboutus/'.$page->gambar)}}" alt="Post Thumbnail">
                    </div>
                  </div>
                  <?php }else{} ?>

                  <div class="entry-content">
                    <p>{!! $page->konten !!}</p>
                  </div>
                  {{-- <div class="entry-footer-meta">
                    <div class="tag-list">
                      <span>
                        <i class="fa fa-tags"></i>
                      </span>
                      <span>
                        <a href="blog.html">Business</a>,
                        <a href="blog.html">Creative</a>,
                        <a href="blog.html">Start-up</a>
                      </span>
                    </div>
                    <div class="author">
                      <span>
                        Author: <a href="blog.html">John Snow</a>
                      </span>
                    </div>
                  </div> --}}
                </article>
                <!-- Single Blog End Here -->

                <!-- Social Sharing Icons Start Here -->
                <div class="post-share">
                  <ul class="social social-sharing">
                    <li class="social__item">
                      <a href="facebook.com" class="social__link facebook">
                        <i class="fa fa-facebook"></i>
                      </a>
                    </li>
                    <li class="social__item">
                      <a href="twitter.com" class="social__link twitter">
                        <i class="fa fa-twitter"></i>
                      </a>
                    </li>
                    <li class="social__item">
                      <a href="plus.google.com" class="social__link pinterest">
                        <i class="fa fa-pinterest-p"></i>
                      </a>
                    </li>
                    <li class="social__item">
                      <a href="plus.google.com" class="social__link google-plus">
                        <i class="fa fa-google-plus"></i>
                      </a>
                    </li>
                  </ul>
                </div>
                <!-- Social Sharing Icons End Here -->
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  <!-- Main Content Wrapper End -->

  <!-- Footer Start-->
  @include('web.components.footer')
  <!-- Footer End-->

  <!-- Searchform Popup Start -->
  <div class="searchform__popup" id="searchForm">
    <a href="#" class="btn-close"><i class="flaticon flaticon-cross"></i></a>
    <div class="searchform__body">
      <p>Start typing and press Enter to search</p>
      <form class="searchform">
        <input type="text" name="popup-search" id="popup-search" class="searchform__input" placeholder="Search Entire Store...">
        <button type="submit" class="searchform__submit"><i class="flaticon flaticon-magnifying-glass-icon"></i></button>
      </form>
    </div>
  </div>
  <!-- Searchform Popup End -->

  <!-- Mini Cart Start -->
  @include('web.components.minicart')
  <!-- Mini Cart End -->

  <!-- Global Overlay Start -->
  <div class="zakas-global-overlay"></div>
  <!-- Global Overlay End -->
</div>
<!-- Main Wrapper End -->
<!-- konten -->
@endsection
