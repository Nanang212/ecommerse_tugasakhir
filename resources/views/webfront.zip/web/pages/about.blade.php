@extends('layouts.web')

@section('content')
<!-- konten -->
<div class="main-wrapper">

    <!-- Header Section Start -->
    @include('web.components.header')

    <!-- konten -->
    <!-- Page Banner Section Start -->
    <div class="page-banner-section section" style="background-image: url(assets/images/blog/single-blog-page-title.jpg)">
        <div class="container">
            <div class="row">
                <div class="page-banner-content col text-center">

                    <h1>Lates and new Trens for baby fashion</h1>

                </div>
            </div>
        </div>
    </div><!-- Page Banner Section End -->

    <!-- Blog Section Start -->
    <div class="blog-section section section-padding">
        <div class="container">
            <div class="row row-30 mbn-40">

                <div class="col-xl-12 col-lg-12 col-12 order-1 order-lg-2 mb-40">
                    <div class="single-blog">
                        <div class="image-wrap">
                            <h4 class="date">May <span>25</span></h4>
                            <a class="image" href="single-blog.html"><img src="{{asset('web/images/blog/single-blog.jpg')}}" alt=""></a>
                        </div>
                        <div class="content">
                            <ul class="meta">
                                <li><a href="#"><img src="{{asset('web/images/blog/blog-author-1.jpg')}}" alt="Blog Author">Muhin</a></li>
                                <li><a href="#">25 Likes</a></li>
                                <li><a href="#">05 Views</a></li>
                            </ul>
                            <div class="desc">
                                <p>Jadusona is one of the most of a exclusive Baby shop in the enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia res eos qui ratione voluptatem sequi Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora inform enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia res eos qui ratione voluptatem sequi Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora inform.</p>
                                <p>Jadusona is one of the most of a exclusive Baby shop in the enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia res eos qui ratione voluptatem sequi Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.</p>
                                <blockquote class="blockquote">
                                    <p>Jadusona is one of the most of a exclusive Baby shop in the enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia res eos qui ratione voluptatem sequi Neque porro quisquam est.</p>
                                    <span>Arif Khan - Designer</span>
                                </blockquote>
                                <p>Jadusona is one of the most of a exclusive Baby shop in the enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia res eos qui ratione voluptatem sequi Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora inform enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.</p>
                            </div>

                            <div class="blog-footer row mt-45">

                                <div class="post-tags col-lg-6 col-12 mv-15">
                                    <h4>Tags:</h4>
                                    <ul class="tag">
                                        <li><a href="#">New</a></li>
                                        <li><a href="#">brand</a></li>
                                        <li><a href="#">black</a></li>
                                        <li><a href="#">white</a></li>
                                        <li><a href="#">chire</a></li>
                                        <li><a href="#">table</a></li>
                                        <li><a href="#">Lorem</a></li>
                                        <li><a href="#">ipsum</a></li>
                                        <li><a href="#">dolor</a></li>
                                        <li><a href="#">sit</a></li>
                                        <li><a href="#">amet</a></li>
                                    </ul>
                                </div>

                                <div class="post-share col-lg-6 col-12 mv-15">
                                    <h4>Share:</h4>
                                    <ul class="share">
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>



            </div>
        </div>
    </div><!-- Blog Section End -->
    <!-- konten -->

    <!-- Brand Section Start -->
    @include('web.components.brand')

    <!-- Footer Top Section Start -->
    @include('web.components.footer')

</div>
<!-- konten -->
@endsection
