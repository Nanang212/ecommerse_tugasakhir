@extends('layouts.web')

<?php $seo = DB::table('seo')->where('id_seo', '1')->first(); ?>
@section('title')
  {{ $seo->title ? $seo->title : 'Store 1' }}
@endsection

@section('description')
  {{ $seo->deskripsi ? $seo->deskripsi : 'Store 1' }}
@endsection

@section('keyword')
  {{ $seo->keyword ? $seo->keyword : 'Store 1' }}
@endsection

@section('content')
    <div class="animsition">
        <div class="full-box">
            <main>
                @include('web.components.header')
                @component('web.components.page_title')
                    Register Sukses
                @endcomponent

                <div class="container">
                    <div class="row center">
                        <div class="col-sm-4">
                            <div>
                                <p class="cancelbtn"><a href="{{route('login')}}">Sign In</a></p>
                            </div>

                        </div>
                    </div>
                </div>
            </main>

          <script type="text/javascript">
          $(document).ready(function() {

            $("#submit").click(function(){

              var dataform = $("#updateform").serialize();

              var token = $("input[name='_token']").val();
              var name = $("#name").val();
              var email = $("#email").val();
              var telepon = $("#telepon").val();
              var password = $("#password").val();

              if(name.length == 0){
                alert("Maaf, Nama tidak boleh kosong");
                $("#name").focus();
                return (false);
              }

              if(email.length == 0){
                alert("Maaf, Email tidak boleh kosong");
                $("#email").focus();
                return (false);
              }

              if(telepon.length == 0){
                alert("Maaf, Telepon tidak boleh kosong");
                $("#telepon").focus();
                return (false);
              }

              if(password.length == 0){
                alert("Maaf, Password tidak boleh kosong");
                $("#password").focus();
                return (false);
              }

              $.ajax({
          		    type: "POST",
          		    url : "/cekemail",
          		    data: "_token="+token+
                    "&email="+email,
          		    beforeSend: function() {
          		        $.LoadingOverlay("show");
          		    },
          		    success: function(msg){
                    //alert(msg);
                    if(msg=='1'){
                      alert('Email sudah digunakan');
                    }else{
                      //konten
                      $.ajax({
                        type: "POST",
                        url : "/registerinsert",
                        data: dataform,
                        beforeSend: function() {
                          //$.LoadingOverlay("show");
                        },
                        success: function(msg){
                          //location.reload();
                          document.location.href="/registersuccess";
                        }
                      });
                      //konten
                    }
                  }
              });

            });

          });
        </script>

            @include('web.components.footer')

        </div>
    </div>
@endsection

@push('styles')
<style>
    .center {
        margin: 20px auto;
    }

    .cancelbtn {
      float: left;
      padding-top: 16px;
    }

    .psw {
      float: right;
      padding-top: 16px;
    }

    @media screen and (max-width: 300px) {
      .psw {
         display: block;
         float: none;
      }

      .cancelbtn {
         width: 100%;
      }
    }
</style>
@endpush
